# Coin Collector - Android Game

A simple and fun coin collecting game built with Godot Engine for Android devices.

## Game Description

**Coin Collector** is an exciting arcade-style game where you control a blue character to collect golden coins while avoiding red obstacles. The game features:

- **Touch Controls**: Touch anywhere on the screen to move your character
- **Progressive Difficulty**: The game gets faster as your score increases
- **Simple but Addictive**: Easy to learn, hard to master gameplay

## How to Play

1. **Movement**: Touch and hold on the screen to move your character towards your finger
2. **Collect Coins**: Touch the yellow coins to collect them and increase your score
3. **Avoid Obstacles**: Stay away from the red squares falling from the top
4. **Restart**: When you hit an obstacle, tap "Restart" to try again

## Game Features

- **Professional 2D Sprites**: Real character sprites from Modern Interiors asset pack
- **Beautiful Visuals**: Custom coin and obstacle graphics with smooth animations  
- **Gradient Background**: Appealing sky-to-ground gradient with cloud details
- **Responsive Touch Controls**: Optimized for mobile devices
- **Progressive Difficulty**: Game speeds up as your score increases
- **Smooth Animations**: Coin collection effects and character movement
- **Portrait Orientation**: Perfect for comfortable mobile play

## Technical Details

- **Engine**: Godot 4.2
- **Platform**: Android (API level optimized for modern devices)
- **Resolution**: 720x1280 (optimized for mobile screens)
- **Controls**: Touch input with keyboard fallback for testing

## Development

This game was created using:
- **Godot Engine 4.2** - Game development framework
- **GDScript** - Primary scripting language
- **Simple geometric shapes** - For quick prototyping and clean visuals

## Installation

1. Open the project in Godot Engine
2. Set up Android export templates (Project → Export → Android)
3. Configure your Android SDK and build tools
4. Export the project as an APK
5. Install on your Android device

## Controls

- **Desktop (for testing)**: WASD or Arrow Keys to move
- **Android**: Touch to move character towards your finger

## Future Enhancements

Potential features for future versions:
- Power-ups and special abilities
- Multiple character skins
- Sound effects and background music  
- Leaderboards and achievements
- Particle effects for coin collection
- Different obstacle types and patterns

Enjoy playing Coin Collector!
